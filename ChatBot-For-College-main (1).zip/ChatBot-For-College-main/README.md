# ChatBot-For-College
It is RULE-BASED chatbot.
You can change questions in index.html file according to your quries.
